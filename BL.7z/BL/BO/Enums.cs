﻿namespace BO;

public enum Category { birthdayCakes, barCakes, barOrBatMitzva, milkeyCakes, cakesCombinedWithPicture };