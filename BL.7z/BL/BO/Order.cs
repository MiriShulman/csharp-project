﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class Order
    {
        public bool PreferredCustomer { get; }
        public List<ProductInOrder> ProductInOrder { get; }
        public double Price { get; }

        public Order(bool preferred, List<ProductInOrder> productIn, double price)
        {
            this.PreferredCustomer = preferred;
            this.ProductInOrder = productIn;
            this.Price = price;

        }
    }
}
