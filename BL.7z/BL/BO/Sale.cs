﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class Sale
    {
        public int Code { get; }
        public int Id { get; }
        public int? MinimumAmount { get; }
        public double? Sum { get; }
        public bool? IsNeedClub { get; }
        public DateTime? BeginSale { get; }
        public DateTime? EndSale { get; }

        public Sale(int code, int id, int min, double sum, bool club, DateTime begin, DateTime end)
        {
            this.Code = code;
            this.Id = id;
            this.MinimumAmount = min;
            this.Sum = sum;
            this.IsNeedClub = club;
            this.BeginSale = begin;
            this.EndSale = end;
        }
    }
}
