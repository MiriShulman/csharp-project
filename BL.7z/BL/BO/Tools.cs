﻿using DO;

namespace BO
{
    internal static class Tools
    {
        public static Customer CastCustomer(DO.Customer customer)
        {
            Customer c = new Customer(customer.id, customer.name, customer.address, customer.phone);
            return c;
        }
        public static DO.Customer CastCustomer(Customer customer)
        {
            return new DO.Customer(customer.Id, customer.Name, customer.Address, customer.Phone);
        }
        public static Product CastProduct(DO.Product product)
        {
            return new Product(product.identity, product.name, product.price, product.amount, (BO.Category)product.c);
        }
        public static Product CastProduct(DO.Product product)
        {
            return new DO.Product(product.identity, product.name, product.price, product.amount, (DO.Category?)product.c);
        }
    }
}
