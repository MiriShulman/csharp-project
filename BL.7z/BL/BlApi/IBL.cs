﻿namespace BlApi
{
    public interface IBL
    {
        public IProduct IProduct { get; }
        public ICustomer ICustomer { get; }
        public ISale ISale { get; }
    }
}
